package apache.poi.ss.usermodel;

public class WorkbookFactory {

	public static Workbook create(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
