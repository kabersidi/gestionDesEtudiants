package apache.poi.ss.usermodel;

public class Row {

	public Object createCell(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
