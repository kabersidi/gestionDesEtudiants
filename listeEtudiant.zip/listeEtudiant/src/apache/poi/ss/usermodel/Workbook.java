package apache.poi.ss.usermodel;

import java.io.FileOutputStream;

public class Workbook {

	public Sheet getSheet(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public Sheet createSheet(String string) {
		// TODO Auto-generated method stub
		return null;
	}


	public void write(FileOutputStream outputStream) {
		// TODO Auto-generated method stub
		
	}

}
