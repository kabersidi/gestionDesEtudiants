package apache.poi.ss.usermodel;

public class Sheet {

	public Row getRow(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getLastRowNum() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Row createRow(int rowNum) {
		// TODO Auto-generated method stub
		return null;
	}

}
