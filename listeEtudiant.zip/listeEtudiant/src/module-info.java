/**
 * 
 */
/**
 * @author PC
 *
 */
module listeEtudiant {
	requires java.desktop;
}