package listeEtudiant;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Formulaire extends JFrame {

    private JTextField nomField, prenomField, matriculeField;
    private JButton ajouterButton, actualiserButton;
    private JList<String> etudiantsList;

    private ArrayList<String> etudiants = new ArrayList<>();

    public Formulaire() {
        // Initialise la fen�tre
        super("Formulaire");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cr�e les champs de texte
        nomField = new JTextField(20);
        prenomField = new JTextField(20);
        matriculeField = new JTextField(10);

        // Cr�e le bouton Ajouter
        ajouterButton = new JButton("Ajouter");
        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ajouterEtudiant();
            }
        });

        // Cr�e le bouton Actualiser
        actualiserButton = new JButton("Actualiser");
        actualiserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualiserListeEtudiants();
            }
        });

        // Cr�e la liste des �tudiants
        etudiantsList = new JList<>(etudiants.toArray(new String[0]));

        // Cr�e un panneau pour la liste des �tudiants et le bouton Actualiser
        JPanel etudiantsPanel = new JPanel(new BorderLayout());
        etudiantsPanel.add(new JScrollPane(etudiantsList), BorderLayout.CENTER);
        etudiantsPanel.add(actualiserButton, BorderLayout.SOUTH);

        // Ajoute les composants � la fen�tre
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));
        panel.add(new JLabel("Nom: "));
        panel.add(nomField);
        panel.add(new JLabel("Pr�nom: "));
        panel.add(prenomField);
        panel.add(new JLabel("Matricule: "));
        panel.add(matriculeField);
        panel.add(new JLabel());
        panel.add(new JLabel());
        panel.add(new JLabel());
        panel.add(ajouterButton);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panel, etudiantsPanel);
        splitPane.setResizeWeight(0.3);

        add(splitPane);

        // Affiche la fen�tre
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void ajouterEtudiant() {
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String matricule = matriculeField.getText();
        
        String etudiant = matricule + ": "+ nom + "/ " + prenom;
        etudiants.add(etudiant);
        etudiantsList.setListData(etudiants.toArray(new String[0]));

        nomField.setText("");
        prenomField.setText("");
        matriculeField.setText("");
    }

    private void actualiserListeEtudiants() {
        // Code pour actualiser la liste des �tudiants (par exemple en lisant un fichier Excel)
    }

    public static void main(String[] args) {
        new Formulaire();
    }
}
