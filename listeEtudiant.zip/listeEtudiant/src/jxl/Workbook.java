package jxl;

import java.io.File;

import jxl.write.WritableWorkbook;

public class Workbook {

	public static WritableWorkbook createWorkbook(File file, WorkbookSettings wbSettings) {
		// TODO Auto-generated method stub
		return null;
	}

}
