package jxl.write;

public class Label {

	public Label(int i, int j, String string) {
		// TODO Auto-generated constructor stub
	}

}
