package jxl.write;

public class WritableSheet {

	public void addCell(Label label) {
		// TODO Auto-generated method stub
		
	}

}
