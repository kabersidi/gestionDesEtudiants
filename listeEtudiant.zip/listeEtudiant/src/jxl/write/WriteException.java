package jxl.write;

public class WriteException {

}
