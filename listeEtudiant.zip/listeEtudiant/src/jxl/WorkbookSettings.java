package jxl;

import java.util.Locale;

public class WorkbookSettings {

	public void setLocale(Locale locale) {
		// TODO Auto-generated method stub
		
	}

}
